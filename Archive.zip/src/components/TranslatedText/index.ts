export { default } from './TranslatedText'
