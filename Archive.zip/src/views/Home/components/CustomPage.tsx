import React from 'react'
import styled from 'styled-components'
import TwitterCard from './TwitterCard'

const StyledCustomPage  = styled.section`
    background-image: url('/bg.png');
    background-repeat: no-repeat;
    background-size: 100% 100%;
    background-color: #FFF;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 0 3rem  0;
`
const MainImage = styled.div`
    height: 25rem;
    width: 20rem;
    margin: 4rem 0 3rem 0;
`

const CustomPage = () => {
    return (
        <StyledCustomPage>
            <MainImage>
                <img src="http://mulfswap.s3-website.ap-south-1.amazonaws.com/static/media/projectLogo.debbac1c.png" alt="" style={{width:"100%",height:"100%"}} />
            </MainImage>
            <TwitterCard />
        </StyledCustomPage>
    )
}

export default CustomPage
