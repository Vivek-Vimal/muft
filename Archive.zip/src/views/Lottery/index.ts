export { default } from './Lottery'
